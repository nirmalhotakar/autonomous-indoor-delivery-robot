#include <AFMotor.h>
#include <Wire.h>
#include <math.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_LIS2MDL.h>
#include <NewPing.h>
#include <Servo.h> 

// ---------------- Ultrasonic & Servo ----------------
#define TRIG_PIN A0
#define ECHO_PIN A1
#define MAX_DISTANCE 200 

NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DISTANCE); 
Servo myservo; 

// ---------------- MPU6050 ----------------
const int MPU = 0x68;
float gyroBiasZ = 0;
float yaw = 0;
unsigned long previousTime;

// ---------------- LIS2MDL Magnetometer ----------------
Adafruit_LIS2MDL mag = Adafruit_LIS2MDL(12345);
float mag_x_offset = -10.58; 
float mag_y_offset = -66.37;
float initialMagOffset = 0;   // Baseline reference for sensor fusion

int leftBaseSpeed  = 200;   
int rightBaseSpeed = 255;   

float heading = 0;          // Desired heading
float Kp = 9.0;             // Proportional gain

// ---------------- Motor Driver ----------------
AF_DCMotor motor1(1, MOTOR12_8KHZ);
AF_DCMotor motor2(2, MOTOR12_8KHZ);
AF_DCMotor motor3(3, MOTOR34_8KHZ);
AF_DCMotor motor4(4, MOTOR34_8KHZ);

// ---------------- Bluetooth & Control ----------------
char command;

// ---------------- Robot State Machine ----------------
enum RobotState {
  IDLE,
  MOVING_FORWARD,
  MOVING_BACKWARD,
  TURNING_LEFT,
  TURNING_RIGHT,
  TURNING_CARDINAL,
  GRID_PLAN,
  GRID_TURN,
  GRID_MOVE,
  MAG_GRID_TURN,
  // --- Sensor-Based True Path-Retention Obstacle Avoidance States ---
  OBSTACLE_AVOID_START,
  OBSTACLE_SIDE_STEP,
  OBSTACLE_BYPASS_FORWARD,
  OBSTACLE_RETURN_STEP
};

RobotState currentState = IDLE;

// ---------------- Turn & Evasion Tracking Variables ----------------
float targetAngle = 90.0;         
float absoluteTargetAngle = 0.0;  

// Sensor-based displacement metrics (in centimeters)
float targetSideDisplacement = 30.0; // Desired lateral offset width in cm
float obstacleBypassDistance = 40.0; // Forward length to pass obstacle in cm
unsigned long lastDistanceMeasureTime = 0;
float estimatedTraveledDistanceCM = 0;

// Conversion scaling from time to cm for movement tracking
const float TIME_PER_CM = 6000.0 / 123.0; 
bool choseRightEvasion = false;
float preEvasionHeading = 0; // To store heading before evasion starts

// ---------------- Path Planning (Sequential System) ----------------
struct PathCommand { 
  float turnAngle; 
  float distance; 
  bool useMagTurn; 
};

PathCommand path[10]; 
int activeWaypoints = 0;
int currentWaypointIndex = 0;

unsigned long accumulatedTime = 0;
unsigned long lastMoveTime = 0;
unsigned long timeToMove = 0;
float desiredGridAngle = 0;
bool activeMagTurnFlag = false;

// Forward declarations
void readBluetooth();
void runStateMachine();
void getYaw();
void forward();
void back();
void Stop();
void turnLeftMotor();
void turnRightMotor();
void calibrateGyro();
float getMagHeadingDegrees();
float getAngleError(float target, float current);
void turnToAbsoluteHeading(float targetHeading);
void setAll(int speed, int direction);
int readPing();
int lookRight();
int lookLeft();
void executeTurn(float targetYawVal);

void setup() {
  Serial.begin(9600);
  Wire.begin();
  
  // Initialize Servo & Ultrasonic Center Position
  myservo.attach(10);  
  myservo.write(115); 
  delay(2000);

  // Wake MPU6050
  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  Wire.setWireTimeout(3000, true); 

  // Explicitly set Gyroscope Configuration to ±250°/s
  Wire.beginTransmission(MPU);
  Wire.write(0x1B); 
  Wire.write(0x00); 
  Wire.endTransmission(true);

  // Initialize LIS2MDL Magnetometer
  if (!mag.begin()) {
    Serial.println("Could not find a valid LIS2MDL sensor, check wiring!");
    while (1);
  }
  Serial.println("LIS2MDL Magnetometer Initialized.");

  Serial.println("Calibrating IMU...");
  delay(1000);
  calibrateGyro();
  
  initialMagOffset = getMagHeadingDegrees();
  Serial.print("Initial Mag Baseline: ");
  Serial.println(initialMagOffset);

  Serial.println("Calibration Complete. Send commands to start.");
  previousTime = micros();
}

void loop() {
  readBluetooth();
  getYaw(); // Continuously updates fused yaw
  runStateMachine();
}

void readBluetooth() {
  if(Serial.available() == 0) return;
  command = Serial.read();
  if(command == '\n' || command == '\r') return;
  
  Serial.print("Received: ");
  Serial.println(command);

  switch(command) {
    // --- Manual Commands ---
    case 'F': heading = yaw; currentState = MOVING_FORWARD; break;
    case 'D': heading = yaw; currentState = MOVING_BACKWARD; break; 
    case 'L': yaw = 0; previousTime = micros(); currentState = TURNING_LEFT; break;
    case 'R': yaw = 0; previousTime = micros(); currentState = TURNING_RIGHT; break;
    case 'S': currentState = IDLE; break; 
    
    // --- Cardinal Direction Commands (N, E, S, W) ---
    case 'N': absoluteTargetAngle = 0.0;   currentState = TURNING_CARDINAL; break; 
    case 'E': absoluteTargetAngle = 90.0;  currentState = TURNING_CARDINAL; break; 
    case 's': absoluteTargetAngle = 180.0; currentState = TURNING_CARDINAL; break; 
    case 'W': absoluteTargetAngle = 270.0; currentState = TURNING_CARDINAL; break;

    // --- Autonomous Obstacle Mode 'O' (Sensor-Driven Path Retention) ---
    case 'O': 
      currentState = OBSTACLE_AVOID_START; 
      Serial.println("Entering Sensor-Based Obstacle Avoidance Mode ('O')");
      break;

    // --- Path A Command ---
    case 'A': 
      path[0] = {0.0, 50.0, false};   
      path[1] = {90.0, 45.0, false};  
      path[2] = {-90.0, 45.0, false}; 
      activeWaypoints = 3;
      currentWaypointIndex = 0;
      currentState = GRID_PLAN;
      Serial.println("Starting Path A");
      break;

    // --- Path B Command ---
    case 'B': 
      path[0] = {0.0, 50.0, false};   
      path[1] = {90.0, 45.0, true};   
      path[2] = {90.0, 45.0, true};   
      activeWaypoints = 3;
      currentWaypointIndex = 0;
      currentState = GRID_PLAN;
      Serial.println("Starting Path B");
      break;

    default: currentState = IDLE; break;
  }
}

void runStateMachine() {
  switch(currentState) {
    case IDLE:
      Stop();
      break;

    case MOVING_FORWARD:
      forward();
      break;

    case MOVING_BACKWARD:
      back();
      break;

    case TURNING_LEFT:
      turnLeftMotor();
      if(yaw >= targetAngle) { Stop(); currentState = IDLE; }
      break;

    case TURNING_RIGHT:
      turnRightMotor();
      if(yaw <= -targetAngle) { Stop(); currentState = IDLE; }
      break;

    case TURNING_CARDINAL: {
      turnToAbsoluteHeading(absoluteTargetAngle);
      float currentHeading = fmod(yaw, 360.0);
      if (currentHeading < 0) currentHeading += 360.0;
      
      float err = getAngleError(absoluteTargetAngle, currentHeading);
      if (abs(err) <= 3.0) {
        Stop();
        heading = absoluteTargetAngle;
        currentState = IDLE;
      }
      break;
    }

    // ---------------- Sensor-Driven Obstacle Avoidance State Machine ----------------
    case OBSTACLE_AVOID_START: {
      int distanceFront = readPing();
      if (distanceFront <= 25 && distanceFront > 0) {
        Stop();
        delay(100);
        back();
        delay(300);
        Stop();
        delay(200);

        int distanceRight = lookRight();
        delay(200);
        int distanceLeft = lookLeft();
        delay(200);

        preEvasionHeading = yaw; // Record original orientation before evasion

        if (distanceRight >= distanceLeft) {
          choseRightEvasion = true;
          heading = preEvasionHeading - 90.0; // Update target heading to right 90 deg
          executeTurn(heading); 
        } else {
          choseRightEvasion = false;
          heading = preEvasionHeading + 90.0; // Update target heading to left 90 deg
          executeTurn(heading); 
        }
        Stop();
        delay(200);

        // Reset distance tracker for sidestep phase
        estimatedTraveledDistanceCM = 0;
        lastDistanceMeasureTime = millis();
        currentState = OBSTACLE_SIDE_STEP;
      } else {
        // Direct inline movement logic (instead of calling forward())
        float error = heading - yaw;
        if (abs(error) < 0.5) error = 0;
        int correction = Kp * error;
        int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
        int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

        motor1.run(FORWARD); motor2.run(FORWARD);
        motor3.run(FORWARD); motor4.run(FORWARD);
        motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
        motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);
      }
      break;
    }

    case OBSTACLE_SIDE_STEP: {
      // Calculate precise cm traveled using time delta scaling while moving sideways
      unsigned long now = millis();
      float dt = (now - lastDistanceMeasureTime) / 1000.0; // seconds
      lastDistanceMeasureTime = now;
      
      float currentSpeedCmPerSec = 123.0 / (6.0); 
      estimatedTraveledDistanceCM += currentSpeedCmPerSec * dt;

      // Direct inline movement logic
      float error = heading - yaw;
      if (abs(error) < 0.5) error = 0;
      int correction = Kp * error;
      int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
      int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

      motor1.run(FORWARD); motor2.run(FORWARD);
      motor3.run(FORWARD); motor4.run(FORWARD);
      motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
      motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);

      // Once we have stepped far enough sideways to clear the track width
      if (estimatedTraveledDistanceCM >= targetSideDisplacement) {
        Stop();
        delay(200);

        // Face parallel back to pre-evasion heading vector
        heading = preEvasionHeading;
        executeTurn(heading);
        Stop();
        delay(200);

        estimatedTraveledDistanceCM = 0;
        lastDistanceMeasureTime = millis();
        currentState = OBSTACLE_BYPASS_FORWARD;
      }
      break;
    }

    case OBSTACLE_BYPASS_FORWARD: {
      unsigned long now = millis();
      float dt = (now - lastDistanceMeasureTime) / 1000.0;
      lastDistanceMeasureTime = now;
      float currentSpeedCmPerSec = 123.0 / (6.0);
      estimatedTraveledDistanceCM += currentSpeedCmPerSec * dt;

      // Direct inline movement logic
      float error = heading - yaw;
      if (abs(error) < 0.5) error = 0;
      int correction = Kp * error;
      int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
      int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

      motor1.run(FORWARD); motor2.run(FORWARD);
      motor3.run(FORWARD); motor4.run(FORWARD);
      motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
      motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);

      // Drive forward parallel until we clear the obstacle's length
      if (estimatedTraveledDistanceCM >= obstacleBypassDistance) {
        Stop();
        delay(200);

        // Turn back toward the original path line
        if (choseRightEvasion) {
          heading = preEvasionHeading + 90.0; // Turn Left back toward line
        } else {
          heading = preEvasionHeading - 90.0; // Turn Right back toward line
        }
        executeTurn(heading);
        Stop();
        delay(200);

        estimatedTraveledDistanceCM = 0;
        lastDistanceMeasureTime = millis();
        currentState = OBSTACLE_RETURN_STEP;
      }
      break;
    }

    case OBSTACLE_RETURN_STEP: {
      unsigned long now = millis();
      float dt = (now - lastDistanceMeasureTime) / 1000.0;
      lastDistanceMeasureTime = now;
      float currentSpeedCmPerSec = 123.0 / (6.0);
      estimatedTraveledDistanceCM += currentSpeedCmPerSec * dt;

      // Direct inline movement logic
      float error = heading - yaw;
      if (abs(error) < 0.5) error = 0;
      int correction = Kp * error;
      int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
      int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

      motor1.run(FORWARD); motor2.run(FORWARD);
      motor3.run(FORWARD); motor4.run(FORWARD);
      motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
      motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);

      // Move forward the exact measured sidestep displacement to snap back onto track
      if (estimatedTraveledDistanceCM >= targetSideDisplacement) {
        Stop();
        delay(200);

        // Re-intercept exact original structural heading vector
        heading = preEvasionHeading;
        executeTurn(heading);
        Stop();
        delay(200);

        Serial.println("Obstacle bypassed via exact distance metrics! Resuming forward.");
        currentState = MOVING_FORWARD; 
      }
      break;
    }

    // ---------------- Sequential Path Logic ----------------
    case GRID_PLAN:
      if (currentWaypointIndex >= activeWaypoints) {
        Stop();
        currentState = IDLE;
        Serial.println("Path Complete!");
        break;
      }

      timeToMove = (unsigned long)(path[currentWaypointIndex].distance * TIME_PER_CM);
      activeMagTurnFlag = path[currentWaypointIndex].useMagTurn;

      if (abs(path[currentWaypointIndex].turnAngle) > 0.1) {
        if (activeMagTurnFlag) {
          float currentMagHeading = getMagHeadingDegrees();
          desiredGridAngle = currentMagHeading + path[currentWaypointIndex].turnAngle;
          if (desiredGridAngle >= 360.0) desiredGridAngle -= 360.0;
          if (desiredGridAngle < 0.0) desiredGridAngle += 360.0;
          
          currentState = MAG_GRID_TURN;
        } else {
          desiredGridAngle = heading + path[currentWaypointIndex].turnAngle;
          currentState = GRID_TURN;
        }
      } else {
        accumulatedTime = 0;
        lastMoveTime = millis();
        currentState = GRID_MOVE;
      }
      break;

    case GRID_TURN: {
      float err = desiredGridAngle - yaw; 
      if (abs(err) > 3.0) { 
        if (err > 0) turnLeftMotor(); 
        else turnRightMotor();
      } else {
        Stop();
        heading = desiredGridAngle; 
        accumulatedTime = 0;      
        lastMoveTime = millis();   
        currentState = GRID_MOVE;
      }
      break;
    }

    case MAG_GRID_TURN: {
      float currentMag = getMagHeadingDegrees();
      float err = desiredGridAngle - currentMag;
      if (err > 180.0)  err -= 360.0;
      if (err < -180.0) err += 360.0;

      if (abs(err) > 4.0) { 
        if (err > 0) turnLeftMotor(); 
        else turnRightMotor();
      } else {
        Stop();
        heading = desiredGridAngle; 
        accumulatedTime = 0;      
        lastMoveTime = millis();   
        currentState = GRID_MOVE;
      }
      break;
    }

    case GRID_MOVE: {
      unsigned long now = millis();
      unsigned long dt = now - lastMoveTime;
      lastMoveTime = now; 

      accumulatedTime += dt; 
      forward(); 
      
      if (accumulatedTime >= timeToMove) {
        Stop();
        currentWaypointIndex++; 
        currentState = GRID_PLAN; 
      }
      break;
    }
  }
}

// ---------------- Helper to block-execute clean precise turns ----------------
void executeTurn(float targetYawVal) {
  float diff = targetYawVal - yaw;
  if (diff > 0) {
    while (yaw < targetYawVal) {
      turnLeftMotor();
      getYaw();
    }
  } else {
    while (yaw > targetYawVal) {
      turnRightMotor();
      getYaw();
    }
  }
}

// ---------------- Ultrasonic Helper Functions ----------------
int readPing() { 
  delay(70);
  int cm = sonar.ping_cm();
  if(cm == 0) {
    cm = 250;
  }
  return cm;
}

int lookRight() {
  myservo.write(50); 
  delay(500);
  int dist = readPing();
  delay(100);
  myservo.write(115); 
  return dist;
}

int lookLeft() {
  myservo.write(170); 
  delay(500);
  int dist = readPing();
  delay(100);
  myservo.write(115); 
  return dist;
}

// ---------------- Magnetometer Raw Heading Function ----------------
float getMagHeadingDegrees() {
  sensors_event_t event;
  mag.getEvent(&event);

  float x = event.magnetic.x - mag_x_offset;
  float y = event.magnetic.y - mag_y_offset;

  float rad = atan2(y, x);
  if (rad < 0) rad += 2 * PI;
  if (rad >= 2 * PI) rad -= 2 * PI;

  return rad * 180.0 / PI;
}

// ---------------- Absolute Turn Helpers & N/E/W/S Implementations ----------------
float getAngleError(float target, float current) {
    float err = target - current;
    while (err > 180.0)  err -= 360.0;
    while (err < -180.0) err += 360.0;
    return err;
}

void turnToAbsoluteHeading(float targetHeading) {
    float currentHeading = fmod(yaw, 360.0);
    if (currentHeading < 0) currentHeading += 360.0;

    float error = getAngleError(targetHeading, currentHeading);
    int turnSpeed = constrain(abs(error) * 5.0, 120, 200);

    if (abs(error) > 3.0) { 
        if (error > 0) {
            motor1.run(BACKWARD); motor2.run(BACKWARD);
            motor3.run(FORWARD);  motor4.run(FORWARD);
        } else {
            motor1.run(FORWARD);  motor2.run(FORWARD);
            motor3.run(BACKWARD); motor4.run(BACKWARD);
        }
        setAll(turnSpeed, -1);
    } else {
        Stop();
    }
}

void faceNorth() { turnToAbsoluteHeading(0.0);   } 
void faceEast()  { turnToAbsoluteHeading(90.0);  } 
void faceSouth() { turnToAbsoluteHeading(180.0); } 
void faceWest()  { turnToAbsoluteHeading(270.0); } 

// ---------------- Motor & IMU Functions ----------------
void forward() {
    float error = heading - yaw;
    if (abs(error) < 0.5) error = 0;

    int correction = Kp * error;
    int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
    int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

    motor1.run(FORWARD); motor2.run(FORWARD);
    motor3.run(FORWARD); motor4.run(FORWARD);

    motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
    motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);
}

void back() {
    float error = heading - yaw;
    if (abs(error) < 0.5) error = 0;

    int correction = Kp * error;
    int leftSpeed  = constrain(leftBaseSpeed  + correction, 0, 255);
    int rightSpeed = constrain(rightBaseSpeed - correction, 0, 255);

    motor1.run(BACKWARD); motor2.run(BACKWARD);
    motor3.run(BACKWARD); motor4.run(BACKWARD);

    motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
    motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);
}

void turnLeftMotor() {
  motor1.run(BACKWARD); motor2.run(BACKWARD);
  motor3.run(FORWARD);  motor4.run(FORWARD);
  setAll(150, -1);
}

void turnRightMotor() {
  motor1.run(FORWARD);  motor2.run(FORWARD);
  motor3.run(BACKWARD); motor4.run(BACKWARD);
  setAll(150, -1);
}

void Stop() {
  setAll(0, RELEASE);
}

void setAll(int speed, int direction) {
  AF_DCMotor* motors[] = { &motor1, &motor2, &motor3, &motor4 };
  for(int i=0; i<4; i++) {
    motors[i]->setSpeed(speed);
    if(direction != -1) motors[i]->run(direction);
  }
}

void calibrateGyro() {
  long sum = 0;
  for(int i=0; i<1000; i++) {
    Wire.beginTransmission(MPU);
    Wire.write(0x47);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU, 2, true);
    int16_t gz = Wire.read()<<8 | Wire.read();
    sum += gz;
    delay(2);
  }
  gyroBiasZ = sum / 1000.0;
}

void getYaw() {
  Wire.beginTransmission(MPU);
  Wire.write(0x47);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU, 2, true);
  int16_t gz = Wire.read()<<8 | Wire.read();
  
  float gyroRate = (gz - gyroBiasZ) / 131.0;
  unsigned long currentTime = micros();
  float dt = (currentTime - previousTime) / 1000000.0;
  previousTime = currentTime;
  
  yaw += gyroRate * dt;

  float currentMag = getMagHeadingDegrees();
  float expectedMag = fmod(yaw, 360.0);
  if (expectedMag < 0) expectedMag += 360.0;
  
  float currentMagRelative = currentMag - initialMagOffset;
  if (currentMagRelative < 0) currentMagRelative += 360.0;
  if (currentMagRelative >= 360.0) currentMagRelative -= 360.0;

  float magError = currentMagRelative - expectedMag;
  if (magError > 180.0)  magError -= 360.0;
  if (magError < -180.0) magError += 360.0;

  if (abs(gyroRate) < 45.0) {
    yaw += magError * 0.03; 
  }
}