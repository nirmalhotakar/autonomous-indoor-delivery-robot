#include <AFMotor.h>
#include <Wire.h>
#include <math.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_LIS2MDL.h>
#include <NewPing.h>
#include <Servo.h>

// ---------------- Ultrasonic & Servo ----------------
#define TRIG_PIN A0
#define ECHO_PIN A1
#define MAX_DISTANCE 200 
NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DISTANCE);
unsigned long lastPingTime = 0;
int currentDistance = 250;

Servo sensorServo;
#define SERVO_PIN 10 
#define ANGLE_LEFT 160
#define ANGLE_CENTER 90
#define ANGLE_RIGHT 20

// ---------------- MPU6050 (Gyro) ----------------
const int MPU = 0x68;
float gyroBiasZ = 0;
float yaw = 0;
unsigned long previousTime;

// ---------------- LIS2MDL Magnetometer ----------------
Adafruit_LIS2MDL mag = Adafruit_LIS2MDL(12345);
float mag_x_offset = -10.58; 
float mag_y_offset = -66.37;
float initialMagOffset = 0;    

// ---------------- Motor Settings ----------------
int leftBaseSpeed  = 200;    
int rightBaseSpeed = 235;    

// *** 90-DEGREE TURN CALIBRATION ***
// This is the absolute minimum speed where your motors can physically turn the robot.
// If the robot stalls at 88 degrees, increase this to 130 or 140.
// If it overshoots to 93 degrees, lower this to 110 or 100.
int minTurnPWM = 125; 

// --- FULL PID CONTROLLER TUNING (For Straight Lines) ---
float heading = 0;           
float Kp = 12.0;  
float Ki = 0.8;   
float Kd = 6.0;   
float lastError = 0.0; 
float integralError = 0.0; 

AF_DCMotor motor1(1, MOTOR12_8KHZ);
AF_DCMotor motor2(2, MOTOR12_8KHZ);
AF_DCMotor motor3(3, MOTOR34_8KHZ);
AF_DCMotor motor4(4, MOTOR34_8KHZ);

// ---------------- Bluetooth & Navigation ----------------
char command;
float targetAngle = 90.0;            
float absoluteTargetAngle = 0.0;  

const float TIME_PER_CM = 6000.0 / 123.0; 

struct PathCommand { 
  float turnAngle; 
  float distance; 
  bool useMagTurn; 
  bool allowAvoidance;
};

PathCommand path[35]; 
int activeWaypoints = 0;
int currentWaypointIndex = 0;

unsigned long accumulatedTime = 0;
unsigned long lastMoveTime = 0;
unsigned long timeToMove = 0;
float desiredGridAngle = 0;
bool activeMagTurnFlag = false;

// Variables for Servo Scan Decision
float scanLeftDistance = 0;
float scanRightDistance = 0;
float originalSegmentRemaining = 0;
unsigned long servoTimer = 0;

enum RobotState {
  IDLE, MOVING_FORWARD, MOVING_BACKWARD, TURNING_LEFT, TURNING_RIGHT, 
  TURNING_CARDINAL, GRID_PLAN, GRID_TURN, GRID_MOVE, MAG_GRID_TURN,
  SERVO_SWEEP_LEFT, SERVO_WAIT_LEFT, SERVO_SWEEP_RIGHT, SERVO_WAIT_RIGHT,
  SERVO_RESET_CENTER, SERVO_WAIT_CENTER, EVALUATE_AND_BYPASS
};

RobotState currentState = IDLE;

void setup() {
  Serial.begin(9600);
  Wire.begin();
  
  sensorServo.attach(SERVO_PIN);
  sensorServo.write(ANGLE_CENTER); 

  Wire.beginTransmission(MPU); Wire.write(0x6B); Wire.write(0); Wire.endTransmission(true);
  Wire.setWireTimeout(3000, true); 
  Wire.beginTransmission(MPU); Wire.write(0x1B); Wire.write(0x00); Wire.endTransmission(true);

  if (!mag.begin()) Serial.println("Warning: LIS2MDL Magnetometer not found.");
  else Serial.println("LIS2MDL Magnetometer Initialized.");

  Serial.println("Calibrating IMU... Do not move robot!");
  delay(1000);
  calibrateGyro();
  
  initialMagOffset = getMagHeadingDegrees();
  Serial.println("Ready.");
  previousTime = micros();
}

void loop() {
  readBluetooth();
  getYaw(); 
  runStateMachine();
}

void readBluetooth() {
  if(Serial.available() == 0) return;
  command = Serial.read();
  if(command == '\n' || command == '\r') return;

  switch(command) {
    case 'F': heading = yaw; currentState = MOVING_FORWARD; break;
    case 'S': case 's': currentState = IDLE; Stop(); break;
    
    case 'A': case 'a': 
      path[0] = {0.0, 300.0, false, true};   
      path[1] = {87.0, 1100.0, false, true}; 
      path[2] = {87.0, 190.0, false, true};  
      
      activeWaypoints = 3;
      currentWaypointIndex = 0;
      currentState = GRID_PLAN;
      lastError = 0;
      integralError = 0;
      Serial.println("Starting Path A");
      break;

    case 'B': case 'b': 
      path[0] = {0.0, 300.0, false, true};   
      path[1] = {87.0, 1100.0, false, true}; 
      path[2] = {-87.0, 130.0, false, true}; // Right turn instead of left
      
      activeWaypoints = 3;
      currentWaypointIndex = 0;
      currentState = GRID_PLAN;
      lastError = 0;
      integralError = 0;
      Serial.println("Starting Path B");
      break;
    
    default: break;
  }
}

void runStateMachine() {
  switch(currentState) {
    case IDLE: Stop(); break;
    case MOVING_FORWARD: forward(); break;
    case MOVING_BACKWARD: back(); break;
    
    case TURNING_LEFT:
      turnLeftMotor(150);
      if(yaw >= targetAngle) { Stop(); currentState = IDLE; }
      break;

    case TURNING_RIGHT:
      turnRightMotor(150);
      if(yaw <= -targetAngle) { Stop(); currentState = IDLE; }
      break;

    case GRID_PLAN:
      if (currentWaypointIndex >= activeWaypoints) {
        Stop(); currentState = IDLE; Serial.println("Destination Reached!"); break;
      }
      timeToMove = (unsigned long)(path[currentWaypointIndex].distance * TIME_PER_CM);
      activeMagTurnFlag = path[currentWaypointIndex].useMagTurn;

      if (abs(path[currentWaypointIndex].turnAngle) > 0.1) {
        desiredGridAngle = heading + path[currentWaypointIndex].turnAngle;
        currentState = GRID_TURN;
      } else {
        accumulatedTime = 0; lastMoveTime = millis(); 
        lastError = 0; integralError = 0; 
        currentState = GRID_MOVE;
      }
      break;

    // --------------------------------------------------------
    // --- THE CREEP AND LOCK 90-DEGREE TURN ALGORITHM ---
    // --------------------------------------------------------
    case GRID_TURN: {
      float err = desiredGridAngle - yaw; 
      while (err > 180.0)  err -= 360.0;
      while (err < -180.0) err += 360.0;

      // Unprecedented tight tolerance: 0.5 degrees
      if (abs(err) > 0.5) { 
        int turnSpeed;
        
        // Stage 1: Coarse Turn (Far away, move fast)
        if (abs(err) > 15.0) {
            turnSpeed = constrain(abs(err) * 3.5 + minTurnPWM, minTurnPWM, 220);
        } 
        // Stage 2: Micro-Creep (Very close, move at absolute minimum speed)
        else {
            turnSpeed = minTurnPWM; 
        }

        if (err > 0) turnLeftMotor(turnSpeed); 
        else turnRightMotor(turnSpeed);
        
      } else {
        // Stage 3: The Soft Brake. Kills momentum without wheel slip.
        if (err > 0) turnRightMotor(minTurnPWM); else turnLeftMotor(minTurnPWM);
        delay(10); 
        Stop();
        
        // Force the heading math to perfectly align for the next straight run
        heading = desiredGridAngle; 
        
        // Reset timing and PID for straight driving
        accumulatedTime = 0; lastMoveTime = millis(); 
        lastError = 0; integralError = 0; 
        
        // Update previousTime so the gyro doesn't glitch from the delay(10)
        previousTime = micros(); 
        
        currentState = GRID_MOVE;
      }
      break;
    }

    case MAG_GRID_TURN: {
      float currentMag = getMagHeadingDegrees();
      float err = desiredGridAngle - currentMag;
      while (err > 180.0)  err -= 360.0;
      while (err < -180.0) err += 360.0;

      if (abs(err) > 0.8) { // Mag data jitters slightly more than gyro, keep at 0.8
        int turnSpeed;
        if (abs(err) > 15.0) {
            turnSpeed = constrain(abs(err) * 3.5 + minTurnPWM, minTurnPWM, 220);
        } else {
            turnSpeed = minTurnPWM; 
        }

        if (err > 0) turnLeftMotor(turnSpeed); 
        else turnRightMotor(turnSpeed);
      } else {
        if (err > 0) turnRightMotor(minTurnPWM); else turnLeftMotor(minTurnPWM);
        delay(10); 
        Stop();
        
        heading = desiredGridAngle; 
        accumulatedTime = 0; lastMoveTime = millis(); 
        lastError = 0; integralError = 0; 
        previousTime = micros(); 
        currentState = GRID_MOVE;
      }
      break;
    }

    case GRID_MOVE: {
      unsigned long now = millis();
      accumulatedTime += (now - lastMoveTime); 
      lastMoveTime = now; 
      
      forward(); 

      if (now - lastPingTime > 50) {
        lastPingTime = now;
        currentDistance = sonar.ping_cm();
        if (currentDistance == 0) currentDistance = 250; 
      }

      if (currentDistance <= 25 && path[currentWaypointIndex].allowAvoidance) {
        Stop();
        float distTraveled = accumulatedTime / TIME_PER_CM;
        originalSegmentRemaining = path[currentWaypointIndex].distance - distTraveled;
        sensorServo.write(ANGLE_LEFT);
        servoTimer = millis();
        currentState = SERVO_WAIT_LEFT;
        break;
      }
      
      if (accumulatedTime >= timeToMove) {
        Stop(); currentWaypointIndex++; currentState = GRID_PLAN; 
      }
      break;
    }
    
    // [Servo Avoidance states]
    case SERVO_WAIT_LEFT:
      if (millis() - servoTimer > 300) { 
        scanLeftDistance = sonar.ping_cm(); if(scanLeftDistance==0) scanLeftDistance=250;
        sensorServo.write(ANGLE_RIGHT); servoTimer = millis(); currentState = SERVO_WAIT_RIGHT;
      }
      break;
    case SERVO_WAIT_RIGHT:
      if (millis() - servoTimer > 400) { 
        scanRightDistance = sonar.ping_cm(); if(scanRightDistance==0) scanRightDistance=250;
        sensorServo.write(ANGLE_CENTER); servoTimer = millis(); currentState = SERVO_WAIT_CENTER;
      }
      break;
    case SERVO_WAIT_CENTER:
      if (millis() - servoTimer > 300) currentState = EVALUATE_AND_BYPASS; break;

    case EVALUATE_AND_BYPASS: {
      bool chooseLeft = (scanLeftDistance >= scanRightDistance);
      float bypassSide = 35.0; float bypassFwd = 45.0;  
      float finalDist = originalSegmentRemaining - bypassFwd;
      if (finalDist < 0) finalDist = 0; 

      PathCommand tempPath[35];
      int originalRemainingCount = activeWaypoints - currentWaypointIndex - 1;
      for(int i = 0; i <= originalRemainingCount; i++) tempPath[i] = path[currentWaypointIndex + 1 + i];

      if (chooseLeft) {
        path[currentWaypointIndex]     = {90.0,  bypassSide, false, false}; 
        path[currentWaypointIndex + 1] = {-90.0, bypassFwd,  false, false}; 
        path[currentWaypointIndex + 2] = {-90.0, bypassSide, false, false}; 
        path[currentWaypointIndex + 3] = {90.0,  finalDist,  false, true};  
      } else {
        path[currentWaypointIndex]     = {-90.0, bypassSide, false, false}; 
        path[currentWaypointIndex + 1] = {90.0,  bypassFwd,  false, false}; 
        path[currentWaypointIndex + 2] = {90.0,  bypassSide, false, false}; 
        path[currentWaypointIndex + 3] = {-90.0, finalDist,  false, true};  
      }

      for(int i = 0; i <= originalRemainingCount; i++) path[currentWaypointIndex + 4 + i] = tempPath[i];
      activeWaypoints = currentWaypointIndex + 4 + originalRemainingCount + 1;
      currentState = GRID_PLAN; currentDistance = 250; 
      break;
    }
  }
}

// ---------------- Motor Control ----------------

void forward() {
    float error = heading - yaw;
    if (abs(error) < 0.2) error = 0;

    integralError += error;
    integralError = constrain(integralError, -25.0, 25.0);
    float derivative = error - lastError;
    
    int correction = (Kp * error) + (Ki * integralError) + (Kd * derivative);
    lastError = error; 

    int leftSpeed  = constrain(leftBaseSpeed  - correction, 0, 255);
    int rightSpeed = constrain(rightBaseSpeed + correction, 0, 255);

    motor1.run(FORWARD); motor2.run(FORWARD);
    motor3.run(FORWARD); motor4.run(FORWARD);
    motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
    motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);
}

void back() {
    float error = heading - yaw;
    if (abs(error) < 0.2) error = 0;

    integralError += error;
    integralError = constrain(integralError, -25.0, 25.0);
    float derivative = error - lastError;

    int correction = (Kp * error) + (Ki * integralError) + (Kd * derivative);
    lastError = error;

    int leftSpeed  = constrain(leftBaseSpeed  + correction, 0, 255);
    int rightSpeed = constrain(rightBaseSpeed - correction, 0, 255);

    motor1.run(BACKWARD); motor2.run(BACKWARD);
    motor3.run(BACKWARD); motor4.run(BACKWARD);
    motor1.setSpeed(leftSpeed); motor2.setSpeed(leftSpeed);
    motor3.setSpeed(rightSpeed); motor4.setSpeed(rightSpeed);
}

void turnLeftMotor(int speed) {
  motor1.run(BACKWARD); motor2.run(BACKWARD);
  motor3.run(FORWARD);  motor4.run(FORWARD);
  setAll(speed, -1);
}

void turnRightMotor(int speed) {
  motor1.run(FORWARD);  motor2.run(FORWARD);
  motor3.run(BACKWARD); motor4.run(BACKWARD);
  setAll(speed, -1);
}

void Stop() { setAll(0, RELEASE); }

void setAll(int speed, int direction) {
  AF_DCMotor* motors[] = { &motor1, &motor2, &motor3, &motor4 };
  for(int i=0; i<4; i++) {
    motors[i]->setSpeed(speed);
    if(direction != -1) motors[i]->run(direction);
  }
}

// ---------------- Sensor Fusion ----------------

float getMagHeadingDegrees() {
  sensors_event_t event; mag.getEvent(&event);
  float x = event.magnetic.x - mag_x_offset;
  float y = event.magnetic.y - mag_y_offset;
  float rad = atan2(y, x);
  if (rad < 0) rad += 2 * PI;
  return rad * 180.0 / PI;
}

void calibrateGyro() {
  long sum = 0;
  for(int i=0; i<1000; i++) {
    Wire.beginTransmission(MPU); Wire.write(0x47); Wire.endTransmission(false);
    Wire.requestFrom(MPU, 2, true);
    int16_t gz = Wire.read()<<8 | Wire.read();
    sum += gz; delay(2);
  }
  gyroBiasZ = sum / 1000.0;
}

float getYaw() {
  Wire.beginTransmission(MPU); Wire.write(0x47); Wire.endTransmission(false);
  Wire.requestFrom(MPU, 2, true);
  int16_t gz = Wire.read()<<8 | Wire.read();
  
  float gyroRate = (gz - gyroBiasZ) / 131.0;
  if (abs(gyroRate) < 0.5) gyroRate = 0.0; 
  
  unsigned long currentTime = micros();
  float dt = (currentTime - previousTime) / 1000000.0;
  previousTime = currentTime;
  
  yaw += gyroRate * dt;

  float currentMag = getMagHeadingDegrees();
  float expectedMag = fmod(yaw, 360.0);
  if (expectedMag < 0) expectedMag += 360.0;
  
  float currentMagRelative = currentMag - initialMagOffset;
  if (currentMagRelative < 0) currentMagRelative += 360.0;
  if (currentMagRelative >= 360.0) currentMagRelative -= 360.0;

  float magError = currentMagRelative - expectedMag;
  if (magError > 180.0)  magError -= 360.0;
  if (magError < -180.0) magError += 360.0;

  // FIX: Include ALL motor states to prevent magnetometer EMF interference
  bool isMotorsActive = (
    currentState == MOVING_FORWARD || 
    currentState == GRID_MOVE || 
    currentState == MOVING_BACKWARD || 
    currentState == GRID_TURN || 
    currentState == TURNING_LEFT || 
    currentState == TURNING_RIGHT
  );
  
  float fusionWeight = isMotorsActive ? 0.0 : 0.04;

  if (abs(gyroRate) < 45.0) {
    yaw += magError * fusionWeight; 
  }
  
  return yaw;
}