import os
import face_recognition
import pickle
import cv2

print("[INFO] Starting face processing...")

# Path to the dataset folder created by the first script
dataset_dir = "dataset"
knownEncodings = []
knownNames = []

# Loop through every person in the dataset folder
for person_name in os.listdir(dataset_dir):
    person_folder = os.path.join(dataset_dir, person_name)

    if not os.path.isdir(person_folder):
        continue

    for image_name in os.listdir(person_folder):
        imagePath = os.path.join(person_folder, image_name)
        print(f"[INFO] Processing: {imagePath}")

        # Load image and convert BGR (OpenCV) to RGB (face_recognition)
        image = cv2.imread(imagePath)
        if image is None:
            continue  # Skip if file isn't a valid image

        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Detect face and encode
        boxes = face_recognition.face_locations(rgb, model="hog")
        encodings = face_recognition.face_encodings(rgb, boxes)

        for encoding in encodings:
            knownEncodings.append(encoding)
            knownNames.append(person_name)  # Uses the folder name as the person's name

print("[INFO] Serializing encodings...")
data = {"encodings": knownEncodings, "names": knownNames}

with open("encodings.pickle", "wb") as f:
    f.write(pickle.dumps(data))

print("[INFO] Training complete! Encodings saved to 'encodings.pickle'")