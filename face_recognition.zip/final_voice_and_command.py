import sys
sys.coinit_flags = 0  # Fixes pythoncom STA threading conflict on Windows

import asyncio
import io
import os
import pickle
import re
import threading
import time
from datetime import datetime
from bleak import BleakClient
import cv2
import face_recognition
import jellyfish
import numpy as np
import pyttsx3
import speech_recognition as sr

# --- CONFIGURATION ---
MAC_ADDRESS = "5F:7C:4F:11:36:34"
CHARACTERISTIC_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"

COMMAND_MAP = {
    "chaitra": "A",
    "nirmal": "C",
    "rutu": "B",
}

TARGET_TO_FACE_MAP = {
    "nirmal": "nirmal",
    "rutu": "rutu",
    "chaitra": "chaitra"
}

# Restricted authorization dataset
AUTHORIZED_NAMES = ["nirmal", "chaitra", "rutu"]
SECURITY_THRESHOLD = 0.5  # Lower is stricter


class UnifiedSecurityRobot:

    def __init__(
        self,
        ble_client: BleakClient,
        loop: asyncio.AbstractEventLoop,
        simulated_travel_seconds=6,
    ):
        self.client = ble_client
        self.loop = loop

        # Speech recognition setup optimized for high sensitivity
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 200  # Highly sensitive threshold
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.pause_threshold = 0.8

        # Initialize microphone
        try:
            self.mic = sr.Microphone()
            print("[INFO] Microphone initialized successfully.")
        except Exception as e:
            print(f"[CRITICAL ERROR] Failed to initialize microphone: {e}")
            self.mic = None

        self._running = False
        self.is_delivering = False
        self.waiting_for_face_verification = False
        self.current_destination = None
        self.pending_command = None
        self.simulated_travel_seconds = simulated_travel_seconds

        # State Management
        self.mode = "VISION"  # "VISION" or "VOICE"
        self.active_authorized_name = None

        # Shared state for live camera face detection check
        self.current_visible_faces = set()
        self.face_lock = threading.Lock()

        # Face recognition data load
        self.load_face_encodings()

    def load_face_encodings(self):
        print("[INFO] Loading facial encodings...")
        try:
            with open("encodings.pickle", "rb") as f:
                data = pickle.loads(f.read())
            self.known_face_encodings = data["encodings"]
            self.known_face_names = data["names"]
            print("[INFO] Facial encodings loaded successfully.")
        except FileNotFoundError:
            print("[ERROR] encodings.pickle not found! Face recognition will run in detection-only mode.")
            self.known_face_encodings = []
            self.known_face_names = []

    def speak(self, text):
        print(f"\n[ROBOT]: {text}")
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", 165)
            engine.say(text)
            engine.runAndWait()
            engine.stop()
        except Exception as e:
            print("TTS Error:", e)

    def calibrate_environment(self):
        if not self.mic:
            return
        with self.mic as source:
            print("Calibrating background noise... Please stay silent for 1 second.")
            try:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
            except Exception as e:
                print(f"Calibration warning: {e}")
        print(f"Calibration ready. Energy cutoff: {self.recognizer.energy_threshold:.0f}")

    def transcribe_audio(self, raw_audio):
        try:
            text = self.recognizer.recognize_google(raw_audio)
            return text.lower()
        except sr.UnknownValueError:
            return ""
        except sr.RequestError as e:
            print(f"Speech API Request Error: {e}")
            return ""
        except Exception as e:
            print(f"Audio processing error: {e}")
            return ""

    def match_phonetic_command(self, spoken_text):
        words = re.findall(r"[a-z]+", spoken_text.lower())
        for word in words:
            word_code = jellyfish.metaphone(word)
            for target_name in COMMAND_MAP.keys():
                target_code = jellyfish.metaphone(target_name)
                if (
                    word_code == target_code
                    or jellyfish.levenshtein_distance(word, target_name) <= 1
                ):
                    return target_name, COMMAND_MAP[target_name]
        return None, None

    def listen_loop(self):
        if not self.mic:
            print("[ERROR] Microphone not available. Voice loop disabled.")
            return

        self.calibrate_environment()
        self.speak("System ready. Waiting for authorized face detection.")
        self._running = True

        while self._running:
            # Sleep if we are currently scanning faces in vision mode
            if self.mode != "VOICE":
                time.sleep(0.5)
                continue

            with self.mic as source:
                print(f"\n[VOICE MODE ACTIVE] Listening for command from {self.active_authorized_name}...")
                try:
                    raw_audio = self.recognizer.listen(
                        source, timeout=10, phrase_time_limit=6
                    )
                except sr.WaitTimeoutError:
                    continue
                except Exception as e:
                    print(f"Listening error: {e}")
                    time.sleep(1)
                    continue

            text = self.transcribe_audio(raw_audio)
            if text:
                print(f"Recognized Speech: '{text}'")
                self.process_command(text)

    def process_command(self, text):
        if "stop" in text:
            self.speak("Stop command received. Shutting down system.")
            self._running = False
            return

        if self.is_delivering:
            print(f"Busy performing task for {self.current_destination}. Input ignored.")
            return

        target_name, command = self.match_phonetic_command(text)
        if target_name and command:
            self.is_delivering = True
            self.current_destination = target_name
            self.pending_command = command
            self.speak(f"Command confirmed for {target_name}. Traveling to destination.")

            timer = threading.Timer(
                self.simulated_travel_seconds,
                self.arrive_at_destination,
                args=[target_name],
            )
            timer.daemon = True
            timer.start()
        else:
            print("No valid command matching (rutu, Nirmal, Chaitra) found.")
            self.speak("Command not recognized. Please try again.")

    def arrive_at_destination(self, destination):
        if self.current_destination == destination:
            self.speak(f"Arrived at location {destination}. Awaiting facial verification to complete delivery.")
            self.waiting_for_face_verification = True
            # Switch back to VISION mode so camera checks for the destination face
            self.mode = "VISION"

    async def send_ble_command(self, command: str):
        try:
            if not self.client.is_connected:
                print("❌ BLE device disconnected. Cannot transmit.")
                return
            await asyncio.wait_for(
                self.client.write_gatt_char(CHARACTERISTIC_UUID, command.encode("utf-8")),
                timeout=5.0
            )
            print(f"--> [BLE Output Transmitted]: '{command}'")
        except asyncio.TimeoutError:
            print("❌ BLE transmission timed out.")
        except Exception as e:
            print(f"❌ Transmission error: {e}")

    def start_vision_loop(self):
        cap = cv2.VideoCapture(0)
        cv_scaler = 4
        frame_count = 0
        start_time = time.time()
        fps = 0

        print("[INFO] Vision Security Feed Armed. Searching for authorized user...")

        while self._running:
            ret, frame = cap.read()
            if not ret:
                print("[ERROR] Failed to grab frame from camera.")
                break

            # If we transitioned to VOICE mode, bypass heavy processing to save CPU
            if self.mode == "VOICE":
                cv2.putText(frame, "MODE: VOICE INPUT ACTIVE", (30, 30), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                cv2.imshow('Security Feed & Voice Robot', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    self._running = False
                    break
                time.sleep(0.05)
                continue

            resized_frame = cv2.resize(frame, (0, 0), fx=(1 / cv_scaler), fy=(1 / cv_scaler))
            rgb_resized_frame = cv2.cvtColor(resized_frame, cv2.COLOR_BGR2RGB)

            face_locations = face_recognition.face_locations(rgb_resized_frame)
            face_encodings = face_recognition.face_encodings(rgb_resized_frame, face_locations)
            face_names = []
            frame_visible_faces = set()

            authorized_detected_name = None
            verified_target_present = False
            expected_face = TARGET_TO_FACE_MAP.get(self.current_destination, "") if self.current_destination else ""

            for face_encoding in face_encodings:
                name = "Unknown"
                if len(self.known_face_encodings) > 0:
                    face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)
                    if len(face_distances) > 0:
                        best_match_index = np.argmin(face_distances)
                        if face_distances[best_match_index] < SECURITY_THRESHOLD:
                            name = self.known_face_names[best_match_index]
                
                face_names.append(name)
                frame_visible_faces.add(name)

                # Check for general login authorization
                if name.lower() in AUTHORIZED_NAMES and not self.is_delivering:
                    authorized_detected_name = name

                # Check for destination verification match
                if self.waiting_for_face_verification and name.lower() == expected_face.lower():
                    verified_target_present = True

            # Update visible faces thread-safely
            with self.face_lock:
                self.current_visible_faces = frame_visible_faces

            # Transition condition: Authorized person spotted -> Stop face recognition, enter voice mode
            if authorized_detected_name and not self.is_delivering:
                print(f"[INFO] Authorized person detected: {authorized_detected_name}. Switching to Voice Input Mode.")
                self.mode = "VOICE"
                self.active_authorized_name = authorized_detected_name
                self.speak(f"Hello {authorized_detected_name}. Authorized face recognized. Please state your command.")

            # Destination verification condition: Arrived at destination and correct target face appears
            if self.waiting_for_face_verification and verified_target_present:
                self.speak(f"Face verified for {expected_face}. Delivery complete.")
                asyncio.run_coroutine_threadsafe(
                    self.send_ble_command(self.pending_command), self.loop
                )
                self.waiting_for_face_verification = False
                self.is_delivering = False
                self.current_destination = None
                self.pending_command = None
                self.active_authorized_name = None
                self.mode = "VISION"
                print("[INFO] Resetting system. Resuming face recognition scan.")

            # Draw bounding boxes and labels
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                top *= cv_scaler
                right *= cv_scaler
                bottom *= cv_scaler
                left *= cv_scaler

                box_color = (0, 255, 0) if name in AUTHORIZED_NAMES else (0, 0, 255)
                cv2.rectangle(frame, (left, top), (right, bottom), box_color, 3)
                cv2.rectangle(frame, (left - 3, top - 35), (right + 3, top), box_color, cv2.FILLED)
                
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left + 6, top - 6), font, 1.0, (255, 255, 255), 1)

                if name in AUTHORIZED_NAMES:
                    cv2.putText(frame, "ACCESS GRANTED", (left + 6, bottom + 23), font, 0.6, (0, 255, 0), 1)

            frame_count += 1
            elapsed_time = time.time() - start_time
            if elapsed_time > 1:
                fps = frame_count / elapsed_time
                frame_count = 0
                start_time = time.time()

            cv2.putText(frame, f"FPS: {fps:.1f}", (frame.shape[1] - 150, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

            cv2.imshow('Security Feed & Voice Robot', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                self._running = False
                break

        cap.release()
        cv2.destroyAllWindows()


async def main():
    print(f"Connecting to BLE device at [{MAC_ADDRESS}]...")
    try:
        async with BleakClient(MAC_ADDRESS) as client:
            if client.is_connected:
                print("✅ Connected to BLE module successfully.")
                loop = asyncio.get_running_loop()

                robot = UnifiedSecurityRobot(
                    ble_client=client,
                    loop=loop,
                    simulated_travel_seconds=6,
                )
                robot._running = True

                voice_thread = threading.Thread(
                    target=robot.listen_loop, daemon=True
                )
                voice_thread.start()

                robot.start_vision_loop()

                print("Disconnecting from BLE device...")

    except Exception as e:
        print(f"⚠️ Connection error: {e}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user.")