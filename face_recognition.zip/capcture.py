import cv2
import os
from datetime import datetime
import time

# Change this to your name (NO SPACES)
PERSON_NAME = "chaitra"


def create_folder(name):
    dataset_folder = "dataset"
    if not os.path.exists(dataset_folder):
        os.makedirs(dataset_folder)

    person_folder = os.path.join(dataset_folder, name)
    if not os.path.exists(person_folder):
        os.makedirs(person_folder)
    return person_folder


def capture_photos(name):
    folder = create_folder(name)

    # Initialize laptop webcam (0 is usually the built-in camera)
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open laptop webcam.")
        return

    time.sleep(1)  # Let camera warm up
    photo_count = 0

    print(f"\n[INFO] Taking photos for '{name}'.")
    print("-> Press SPACE to capture a photo.")
    print("-> Press 'q' to quit when you have enough (about 10-15 photos).\n")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break

        cv2.imshow('Capture - Press SPACE to snap, Q to quit', frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord(' '):  # Space key
            photo_count += 1
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{name}_{timestamp}.jpg"
            filepath = os.path.join(folder, filename)
            cv2.imwrite(filepath, frame)
            print(f"Photo {photo_count} saved: {filepath}")

        elif key == ord('q'):  # Quit
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    capture_photos(PERSON_NAME)